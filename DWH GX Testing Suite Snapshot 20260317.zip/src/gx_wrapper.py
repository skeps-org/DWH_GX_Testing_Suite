import great_expectations as gx
import toml
import yaml
import pandas as pd
import logging
import logging.config
import os
import warnings
import sqlalchemy
import datetime
from urllib.parse import quote_plus

# Ensure logs dir exists
if not os.path.exists('logs'):
    os.makedirs('logs')

logging.config.fileConfig('config/logging.conf')
logger = logging.getLogger('dq_engine')

class GXRunner:
    def __init__(self, secrets_path="secrets.toml", rules_path="config/gx_rules.yaml"):
        self.secrets = toml.load(secrets_path)['lenders']
        with open(rules_path, 'r') as f:
            self.rules = yaml.safe_load(f)

    def _build_connection_string(self, creds):
        safe_user = quote_plus(creds['user'])
        safe_password = quote_plus(creds['password'])
        return f"mysql+mysqlconnector://{safe_user}:{safe_password}@{creds['host']}:{creds.get('port', 3306)}/{creds['db']}"

    def _get_table_count(self, creds, table_name):
        try:
            conn_str = self._build_connection_string(creds)
            engine = sqlalchemy.create_engine(conn_str)
            with engine.connect() as conn:
                query = sqlalchemy.text(f"SELECT COUNT(*) FROM {table_name}")
                result = conn.execute(query).scalar()
                return int(result)
        except Exception as e:
            logger.warning(f"Could not fetch row count for {table_name}: {e}")
            return 0 
    

    def run_validation(self, lender_id, specific_table=None):
        logger.info(f"Initializing GX for {lender_id}...")
        all_results = []
        
        try:
            context = gx.get_context(mode="ephemeral")
            creds = self.secrets[lender_id]
            ds_name = f"ds_{lender_id}"
            
            conn_str = self._build_connection_string(creds)
            data_source = context.data_sources.add_sql(name=ds_name, connection_string=conn_str)
            
            if specific_table:
                if specific_table not in self.rules['tables']:
                    logger.warning(f"Table {specific_table} requested but not found in rules YAML.")
                    return pd.DataFrame()
                target_tables = [specific_table]
            else:
                target_tables = list(self.rules['tables'].keys())
            
            for table_name in target_tables:
                logger.info(f"[{lender_id}] Starting validation for table: {table_name}")
                asset_name = f"asset_{lender_id}_{table_name}"
                try:
                    data_asset = data_source.get_asset(asset_name)
                except LookupError:
                    data_asset = data_source.add_table_asset(name=asset_name, table_name=table_name)
                
                batch_def = data_asset.add_batch_definition_whole_table(f"batch_{table_name}")
                suite_name = f"suite_{lender_id}_{table_name}"
                suite = context.suites.add(gx.ExpectationSuite(name=suite_name))
                
                table_config = self.rules['tables'][table_name]
                
                # Strict enforcement: Config MUST be a dictionary with 'primary_key'
                if not isinstance(table_config, dict):
                    logger.error(f"Invalid configuration for table {table_name}. Must be a dictionary with 'primary_key'.")
                    continue
                    
                table_rules = table_config.get('expectations', [])
                pk_config = table_config.get('primary_key')
                
                if not pk_config:
                    logger.error(f"Table {table_name} missing 'primary_key' configuration.")
                    continue
                    
                if isinstance(pk_config, list):
                    primary_keys = pk_config
                else:
                    primary_keys = [pk_config]

                from great_expectations import expectations as gxe
                
                with warnings.catch_warnings():
                    warnings.filterwarnings("ignore", message=".*unexpected_rows_query should contain the {batch} parameter.*")
                    
                    for exp_config in table_rules:
                        # Check if this expectation has specific target lenders
                        target_lenders = exp_config.get('target_lenders')
                        if target_lenders and lender_id not in target_lenders:
                            logger.info(f"[{lender_id}] Skipping test '{exp_config.get('name')}' as lender is not in target_lenders.")
                            continue

                        meta_data = exp_config.get('meta', {})
                        meta_data['test_alias'] = exp_config.get('name') 
                        
                        # Store PK config for CSV generation
                        meta_data['primary_keys'] = primary_keys

                        if exp_config['type'] == "unexpected_rows_expectation":
                            exp_instance = gxe.UnexpectedRowsExpectation(**exp_config['kwargs'])
                            exp_instance.meta = meta_data
                            suite.add_expectation(exp_instance)
                        else:
                            camel_name = "".join([x.capitalize() for x in exp_config['type'].split('_')])
                            if hasattr(gxe, camel_name):
                                exp_class = getattr(gxe, camel_name)
                                exp_instance = exp_class(**exp_config['kwargs'])
                                exp_instance.meta = meta_data
                                suite.add_expectation(exp_instance)
                            else:
                                logger.warning(f"Expectation {camel_name} not found.")

                    val_def = context.validation_definitions.add(
                        gx.ValidationDefinition(data=batch_def, suite=suite, name=f"val_{lender_id}_{table_name}")
                    )
                    
                    checkpoint = context.checkpoints.add(
                        gx.Checkpoint(
                            name=f"chk_{lender_id}_{table_name}", 
                            validation_definitions=[val_def], 
                            result_format={
                                "result_format": "COMPLETE",
                                "unexpected_index_column_names": primary_keys,
                                "partial_unexpected_count": 5000
                            }
                        )
                    )
                    
                    result = checkpoint.run()

                # Pass table_name to parse_results for better logging context
                # Pass creds so we can re-run queries if needed
                df = self._parse_results(lender_id, result, table_name, creds)
                all_results.append(df)

            if all_results:
                return pd.concat(all_results, ignore_index=True)
            return pd.DataFrame()

        except Exception as e:
            logger.error(f"GX Critical Failure for {lender_id}: {e}")
            return pd.DataFrame([{
                "lender": lender_id,
                "table": "SYSTEM",
                "status": "CRITICAL_ERROR",
                "test_description": "GX_Execution",
                "error_msg": str(e),
                "severity": "critical",
                "failed_rows": 0,
                "total_rows": 0
            }])

    def _extract_error_message(self, info_dict):
        if not isinstance(info_dict, dict):
            return None
        if info_dict.get("exception_message"):
            return info_dict.get("exception_message")
        if info_dict.get("exception_traceback"):
            return info_dict.get("exception_traceback").strip().split('\n')[-1]
        for key, value in info_dict.items():
            if isinstance(value, dict):
                found = self._extract_error_message(value)
                if found:
                    return found
        return None

    def _parse_results(self, lender_id, checkpoint_result, table_name, creds):
        parsed_rows = []
        
        run_result = list(checkpoint_result.run_results.values())[0]
        if isinstance(run_result, dict) and 'validation_result' in run_result:
            validation_result = run_result['validation_result']
        else:
            validation_result = run_result
        
        cached_table_count = None
        
        for res in validation_result.results:
            exp_config = res.expectation_config
            meta = exp_config.meta or {}

            if exp_config.type == "unexpected_rows_expectation":
                # SQL-based expectation
                unexpected_rows = res.result.get("unexpected_rows")
                if unexpected_rows is None:
                    unexpected_rows = res.result.get("details", {}).get("unexpected_rows", [])
                
                unexpected_count = len(unexpected_rows)

                # DEBUG: Use metrics count if available
                if "unexpected_count" in res.result:
                    unexpected_count = int(res.result["unexpected_count"])
                
                if cached_table_count is None:
                    cached_table_count = self._get_table_count(creds, table_name)

                element_count = cached_table_count

            else:
                # Metric-based expectation
                unexpected_count = int(res.result.get("unexpected_count", 0))
                raw_element_count = int(res.result.get("element_count", 0))

                if raw_element_count == 0:
                    if cached_table_count is None:
                        cached_table_count = self._get_table_count(creds, table_name)
                    element_count = cached_table_count
                else:
                    element_count = raw_element_count

            if res.success:
                status = "PASS"
                error_msg = ""
            elif unexpected_count > 0:
                status = "FAIL"
                if unexpected_count == 200:
                    error_msg = f"Found at least {unexpected_count} data failures (Display limit). Check CSV for full details."
                else:
                    error_msg = f"Found {unexpected_count} data failures"
            else:
                status = "ERROR"
                raw_msg = self._extract_error_message(res.exception_info)
                if raw_msg:
                    error_msg = str(raw_msg)[:2000]
                else:
                    logger.error(f"Failed to extract error message. Raw info: {res.exception_info}")
                    error_msg = "Unknown execution error (Check logs)"
            
            if meta.get('test_alias'):
                display_name = meta['test_alias']
            else:
                if exp_config.type == "unexpected_rows_expectation":
                    display_name = "Custom SQL Check"
                else:
                    display_name = exp_config.type

            severity = meta.get('severity', 'warning')
            
            # --- Detailed Logging ---
            log_msg = f"[{lender_id}] [{table_name}] Test: {display_name} | Status: {status}"
            if status in ["FAIL", "ERROR"]:
                logger.warning(f"{log_msg} - {error_msg}")
            else:
                logger.info(log_msg)
            
            parsed_rows.append({
                "lender": lender_id,
                "table": table_name,
                "test_description": meta.get('description', display_name),
                "status": status,
                "failed_rows": unexpected_count,
                "total_rows": element_count,
                "severity": severity,
                "error_msg": error_msg
            })
            
            # --- CSV Generation (Modified to allow re-running query) ---
            if status == "FAIL":
                self._generate_failure_csv(lender_id, table_name, display_name, res, creds)

        return pd.DataFrame(parsed_rows)

    def _generate_failure_csv(self, lender_id, table_name, test_name, result_obj, creds):
        """
        Generates a CSV file for failed tests.
        Filename format: lender_table_test_name_testruntime.csv
        Content: lender_name, table_name, test_name, [pk_cols...], expected_value, actual_value
        """
        try:
            # Create directory if not exists
            output_dir = "failed_rows"
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)

            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            # Sanitize filename components
            safe_test_name = "".join([c if c.isalnum() else "_" for c in test_name])
            filename = f"{lender_id}_{table_name}_{safe_test_name}_{timestamp}.csv"
            filepath = os.path.join(output_dir, filename)

            rows_to_save = []
            
            # Retrieve configured PKs from meta
            meta = result_obj.expectation_config.meta or {}
            primary_keys = meta.get('primary_keys', [])
            description = meta.get('description', 'Pass Expectation')
            
            # CHECK: If this is a SQL expectation, bypass GX limits and run query directly
            exp_config = result_obj.expectation_config
            if exp_config.type == "unexpected_rows_expectation" and "unexpected_rows_query" in exp_config.kwargs.get('kwargs', exp_config.kwargs):
                # exp_config.kwargs sometimes is wrapped or not depending on object type? 
                # result_obj.expectation_config is usually an ExpectationConfiguration object.
                # Accessing .kwargs is fine.
                
                query = exp_config.kwargs.get("unexpected_rows_query")
                logger.info(f"Downloading full failed rows directly from DB for {test_name}...")
                
                try:
                    conn_str = self._build_connection_string(creds)
                    # Use pandas to read sql
                    df_fail_direct = pd.read_sql(query, conn_str)
                    unexpected_items = df_fail_direct.to_dict(orient='records')
                except Exception as db_err:
                    logger.error(f"Direct DB fetch failed: {db_err}. Falling back to GX results.")
                    # Fallback to GX results
                    unexpected_list = result_obj.result.get("unexpected_list", [])
                    unexpected_rows = result_obj.result.get("unexpected_rows")
                    if unexpected_rows is None:
                        unexpected_rows = result_obj.result.get("details", {}).get("unexpected_rows", [])
                    unexpected_items = unexpected_list or unexpected_rows or []

            else:
                # Default GX behavior
                unexpected_list = result_obj.result.get("unexpected_list", [])
                unexpected_rows = result_obj.result.get("unexpected_rows")
                if unexpected_rows is None:
                    unexpected_rows = result_obj.result.get("details", {}).get("unexpected_rows", [])
                
                if unexpected_list:
                    unexpected_items = unexpected_list
                else:
                    unexpected_items = unexpected_rows or []

            def _build_row(item):
                row = {
                    "lender_name": lender_id,
                    "table_name": table_name,
                    "test_name": test_name
                }
                
                # Dynamic PK columns
                if isinstance(item, dict):
                    for pk in primary_keys:
                        val = item.get(pk)
                        row[pk] = str(val) if val is not None else "N/A"
                else:
                    row["raw_item"] = str(item)
                
                row["expected_value"] = description if description != 'Pass Expectation' else "0 rows returned"
                
                # Refine actual_value
                if isinstance(item, dict):
                    # Filter out PKs to find the "actual value" content
                    actual_content = {k: v for k, v in item.items() if k not in primary_keys}
                    
                    if len(actual_content) == 1:
                        row["actual_value"] = str(list(actual_content.values())[0])
                    else:
                        row["actual_value"] = str(actual_content)
                else:
                    row["actual_value"] = str(item)
                
                return row

            for item in unexpected_items:
                rows_to_save.append(_build_row(item))

            if rows_to_save:
                df_fail = pd.DataFrame(rows_to_save)
                
                # Define column order: Context -> PKs -> Expected -> Actual
                cols = ["lender_name", "table_name", "test_name"] + primary_keys + ["expected_value", "actual_value"]
                
                # Ensure all columns exist
                for c in cols:
                    if c not in df_fail.columns:
                        df_fail[c] = "N/A"
                
                # Select only relevant columns
                df_fail = df_fail[cols]
                
                df_fail.to_csv(filepath, index=False)
                logger.info(f"Generated failure report: {filepath}")
        
        except Exception as e:
            logger.error(f"Failed to generate CSV for {test_name}: {e}")